/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  eslint: {
    // eslint isn't configured to gate deploys yet — don't fail the
    // Netlify build over lint errors.
    ignoreDuringBuilds: true,
  },
};

export default nextConfig;
