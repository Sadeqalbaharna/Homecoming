"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  Menu, X, ShoppingCart, Plus, Minus, CalendarDays, ChevronLeft, ChevronRight,
  Swords, Sparkles, FlaskConical, Moon, MapPin, Phone, Clock, Users, Check, Flame, Layers
} from "lucide-react";
import { doc, getDoc, collection, addDoc, serverTimestamp } from "firebase/firestore";
import { ref, get as rtdbGet } from "firebase/database";
import { signInAnonymously } from "firebase/auth";
import { db, rtdb, auth } from "@/lib/firebase";

/* ---------- Design tokens ---------- */
// BASE_C is the fallback palette. The five accent colors the owner can
// retheme from the console (brass, brassBright, ember, emberBright,
// alchemyGlow) get merged over this inside TavernSite() as a *local*
// `C` that shadows this module-level one — so every existing `C.xxx`
// reference in the component picks up the live theme automatically.
const BASE_C = {
  oak: "#1B1611",
  oakDeep: "#120E0A",
  parchment: "#EFE3C2",
  parchmentDim: "#E4D6AE",
  ink: "#2A2016",
  cream: "#F3EAD3",
  brass: "#B98B3E",
  brassBright: "#D8AC5C",
  ember: "#9C3B2C",
  emberBright: "#C24E39",
  alchemy: "#2C4238",
  alchemyDeep: "#1B2921",
  alchemyGlow: "#8FC79E",
};

const FONT_IMPORT =
  "@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;900&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=IBM+Plex+Mono:wght@400;500;600&display=swap');";

const display = { fontFamily: "'Cinzel', serif" };
const body = { fontFamily: "'Fraunces', serif" };
const mono = { fontFamily: "'IBM Plex Mono', monospace" };

const fmt = (n) => `BHD ${Number(n || 0).toFixed(3)}`;

/* ---------- Site content: live from RTDB /site_content, owner-edited via the
   Tavern Console's "Site Content" tab. Everything below is the fallback shown
   before that node exists (or if a read fails), so the site never looks
   empty/broken on first load. ---------- */
const ICON_MAP = { Layers, FlaskConical, Swords, Sparkles, Moon };

const DEFAULT_STORE = [
  { id: "dice", name: "Brass-Cast Dice Set", cat: "Merch", price: 12.0, desc: "Hand-weighted 7-piece set, engraved case.", icon: "Layers" },
  { id: "mug", name: "Tavern Pewter Tankard", cat: "Merch", price: 14.0, desc: "The house tankard. Holds a proper pour.", icon: "FlaskConical" },
  { id: "ledger", name: "Hand-Bound Ledger", cat: "Merch", price: 9.5, desc: "Blank pages, wax-sealed clasp, campaign-ready.", icon: "Layers" },
  { id: "dnd", name: "D&D Night — Single Seat", cat: "Tickets", price: 8.0, desc: "One drop-in table seat, any Thursday.", icon: "Swords" },
  { id: "mtg", name: "MTG Game Night Entry", cat: "Tickets", price: 6.0, desc: "Draft or Commander, packs included where noted.", icon: "Sparkles" },
  { id: "coaster", name: "Grimoire Coaster Set", cat: "Merch", price: 7.0, desc: "Four rune-etched coasters, cork-backed.", icon: "Layers" },
  { id: "latehours", name: "Alchemy House Late Hours Entry", cat: "Tickets", price: 5.0, desc: "21+, priority seating upstairs after 9pm.", icon: "Moon" },
];

const DEFAULT_CONTENT = {
  hero: {
    headline: "THE TAVERN",
    tagline: "A hearth downstairs for the whole family. A hushed alchemy bar up the stairs. One roof, two hours of the evening.",
    label: "ADLIYA · BLOCK 338 · BAHRAIN",
    bgImageUrl: "",
  },
  floors: {
    mainHallDesc: "Long oak tables, hearty plates, and a corner given over to dice and cards most Thursdays. D&D nights and Magic: The Gathering drop-ins run weekly — bring your own deck, or borrow ours.",
    alchemyDesc: "A quieter bar up the stairs: colour-shifting cocktails, low light, and a rune-covered blackboard behind the counter. Guided potion-making sessions run from the corner apothecary shelf.",
  },
  potionsIntro: "Three potions brewed at a rune-covered blackboard, one keepsake vessel to take home. Alcoholic and non-alcoholic versions available. The alchemist handles anything with flame or dry ice.",
  potionsPrice: 25.0,
  potions: [
    { name: "Moonchange Draught", note: "Colour-shifting, citrus-forward" },
    { name: "Dragon's Breath", note: "Dry-ice theatrics, spiced" },
    { name: "Astral Reverie", note: "Lavender, edible stardust" },
  ],
  contact: {
    phone: "+973 XXXX XXXX",
    address: "Block 338, Adliya, Kingdom of Bahrain",
    hoursMainHall: "Daily, 12:00 PM – 11:00 PM",
    hoursAlchemy: "Daily, 6:00 PM – 1:00 AM",
  },
  social: {
    tavernHandle: "@thetavern.bh", tavernUrl: "",
    alchemyHandle: "@alchemyhouse.bh", alchemyUrl: "",
  },
  store: DEFAULT_STORE,
  sectionOrder: ["floors", "menu", "events", "schedule", "potions", "store", "book", "visit"],
  // Per-section eyebrow label + heading text, plus a hide toggle — all
  // editable from the console's Site Content tab. "visit" has a second
  // label/heading because that section renders two side-by-side blocks
  // (contact info + social).
  sectionMeta: {
    floors: { label: "TWO FLOORS, ONE STAIRCASE", heading: "Choose your floor", hidden: false },
    menu: { label: "THE LEDGER", heading: "What's on the table", hidden: false },
    events: { label: "WEEKLY GATHERINGS", heading: "The event calendar", hidden: false },
    schedule: { label: "WEEKLY RHYTHM", heading: "The weekly schedule", hidden: false },
    potions: { label: "UP THE STAIRS · THE POTION CORNER", heading: "The Potion-Making Experience", hidden: false },
    store: { label: "TAKE SOMETHING HOME", heading: "The store", hidden: false },
    book: { label: "SAVE A SEAT", heading: "Book a table", hidden: false },
    visit: { label: "FIND US", heading: "Visit the tavern", label2: "FOLLOW ALONG", heading2: "Two floors, two feeds", hidden: false },
  },
  // The five accent colors the owner can retheme. Backgrounds/text/ink stay
  // fixed so the site can't accidentally become unreadable.
  theme: {
    brass: "#B98B3E",
    brassBright: "#D8AC5C",
    ember: "#9C3B2C",
    emberBright: "#C24E39",
    alchemyGlow: "#8FC79E",
  },
  brand: {
    name: "THE TAVERN",
    footerNote: "© 2026 · Adliya, Bahrain",
  },
  buttons: {
    reserveTable: "RESERVE A TABLE",
    viewMenu: "VIEW THE MENU",
    addTicket: "ADD A TICKET",
  },
  // Per-section background media — owner-editable via the console's Section
  // Backgrounds panel. Every section (hero + the eight reorderable ones)
  // can carry an image or video that sits behind its content, with
  // adjustable position/size/darkening so text stays readable. "type: none"
  // (the default) keeps the section's original solid/gradient look.
  background: {
    hero: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    floors: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    menu: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    events: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    schedule: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    potions: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    store: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    book: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
    visit: { type: "none", url: "", size: "cover", posX: 50, posY: 50, overlay: 0.5 },
  },
};

// Every id a background can be set on: hero plus the eight reorderable
// sections. Kept separate from DEFAULT_SECTION_ORDER since hero isn't
// reorderable but still needs a background slot.
const BG_IDS = ["hero", "floors", "menu", "events", "schedule", "potions", "store", "book", "visit"];

/* Every section between Hero and Footer is reorderable from the console's
   Site Content tab (drag-and-drop). Hero ("home") and the Footer are fixed —
   they're not content sections, they're the page's frame. SECTION_META gives
   the nav label for each reorderable id; DEFAULT_SECTION_ORDER is the order
   used if siteContent.sectionOrder is missing or invalid (wrong length, or
   an id that isn't one of these seven). */
const SECTION_META = {
  floors: { label: "The Floors" },
  menu: { label: "Menu" },
  events: { label: "Events" },
  schedule: { label: "Schedule" },
  potions: { label: "Potions" },
  store: { label: "Store" },
  book: { label: "Book" },
  visit: { label: "Visit" },
};
const DEFAULT_SECTION_ORDER = ["floors", "menu", "events", "schedule", "potions", "store", "book", "visit"];

const isValidSectionOrder = (arr) =>
  Array.isArray(arr) &&
  arr.length === DEFAULT_SECTION_ORDER.length &&
  [...arr].sort().join(",") === [...DEFAULT_SECTION_ORDER].sort().join(",");

// Merges a raw sectionMeta object (possibly partial/missing) onto the
// defaults, per section id, so an owner who's only customized one section's
// heading doesn't lose the labels for the other six.
const mergeSectionMeta = (raw) => {
  const merged = {};
  for (const id of DEFAULT_SECTION_ORDER) {
    merged[id] = { ...DEFAULT_CONTENT.sectionMeta[id], ...((raw && raw[id]) || {}) };
  }
  return merged;
};

// Same merge pattern as mergeSectionMeta, but for per-section background
// media — every id in BG_IDS always ends up with a complete, valid record
// (type/url/size/posX/posY/overlay) even if the owner has only customized
// one section's background so far, or none at all yet.
const mergeBackground = (raw) => {
  const merged = {};
  for (const id of BG_IDS) {
    merged[id] = { ...DEFAULT_CONTENT.background[id], ...((raw && raw[id]) || {}) };
  }
  return merged;
};

const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DOW = ["S","M","T","W","T","F","S"];

const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const DIET_BADGES = [
  { key: "isNew", label: "NEW", color: BASE_C.brassBright },
  { key: "isBestSeller", label: "BEST SELLER", color: BASE_C.emberBright },
  { key: "isVegan", label: "VEGAN", color: BASE_C.alchemyGlow },
  { key: "isVegetarian", label: "VEG", color: BASE_C.alchemyGlow },
  { key: "isGlutenFree", label: "GF", color: BASE_C.parchmentDim },
];

/* ---------- Small components ---------- */
function SectionLabel({ children, color }) {
  return (
    <div className="inline-flex items-center gap-2 mb-4">
      <span style={{ width: 24, height: 1, background: color || BASE_C.brass }} />
      <span style={{ ...mono, color: color || BASE_C.brass, letterSpacing: "0.18em", fontSize: 12 }}>{children}</span>
    </div>
  );
}

/* Wraps a <section> with an optional image/video background layer + a
   darkening overlay (so the section's text stays readable), falling back to
   that section's original solid/gradient look when no media is set. Every
   existing section's content goes in unmodified as children — this only
   changes what sits behind it. */
function SectionBackdrop({ id, className, fallback, bg, children }) {
  const hasMedia = !!(bg && bg.type !== "none" && bg.url);
  const posStyle = `${bg?.posX ?? 50}% ${bg?.posY ?? 50}%`;
  return (
    <section id={id} className={className} style={{ position: "relative", overflow: "hidden", background: hasMedia ? "#000" : fallback }}>
      {hasMedia && bg.type === "image" && (
        <div
          aria-hidden="true"
          style={{
            position: "absolute", inset: 0,
            backgroundImage: `url(${bg.url})`,
            backgroundSize: bg.size === "contain" ? "contain" : "cover",
            backgroundPosition: posStyle,
            backgroundRepeat: "no-repeat",
          }}
        />
      )}
      {hasMedia && bg.type === "video" && (
        <video
          aria-hidden="true"
          autoPlay
          muted
          loop
          playsInline
          src={bg.url}
          style={{
            position: "absolute", inset: 0,
            width: "100%", height: "100%",
            objectFit: bg.size === "contain" ? "contain" : "cover",
            objectPosition: posStyle,
          }}
        />
      )}
      {hasMedia && (
        <div aria-hidden="true" style={{ position: "absolute", inset: 0, background: `rgba(0,0,0,${bg.overlay ?? 0.5})` }} />
      )}
      <div style={{ position: "relative", zIndex: 1 }}>{children}</div>
    </section>
  );
}

function StairRail({ progress, theme }) {
  const T = theme || BASE_C;
  return (
    <div
      className="hidden lg:flex fixed right-6 top-0 h-screen items-center z-30 pointer-events-none"
      aria-hidden="true"
    >
      <div style={{ position: "relative", width: 2, height: "70vh", background: "rgba(185,139,62,0.25)" }}>
        <div
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            width: 2,
            height: `${progress}%`,
            background: `linear-gradient(to top, ${T.brass}, ${T.alchemyGlow})`,
            transition: "height 0.1s linear",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: `${progress}%`,
            left: "50%",
            transform: "translate(-50%, 50%)",
            width: 10,
            height: 10,
            borderRadius: "50%",
            background: T.brassBright,
            boxShadow: `0 0 10px 3px ${T.brassBright}`,
            transition: "bottom 0.1s linear",
          }}
        />
      </div>
    </div>
  );
}

/* ---------- Main ---------- */
export default function TavernSite() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrollPct, setScrollPct] = useState(0);
  const [activeSection, setActiveSection] = useState("home");

  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState("cart");
  const [checkoutForm, setCheckoutForm] = useState({ name: "", email: "" });
  const [orderRef, setOrderRef] = useState("");

  /* Live events — Firestore huntboard/events, keyed by ISO date */
  const [events, setEvents] = useState({});
  const [eventsLoading, setEventsLoading] = useState(true);

  /* Live weekly schedule — Firestore huntboard/schedules, same doc the
     console's Quest Board "Schedule" tab writes to. A recurring
     day-of-week rundown (not date-specific), separate from the Events
     calendar above. */
  const [schedule, setSchedule] = useState([]);
  const [scheduleLoading, setScheduleLoading] = useState(true);
  const [calMonth, setCalMonth] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [selectedDate, setSelectedDate] = useState(() => todayISO());

  /* Live menu — Realtime Database /menu. One shared list for both floors
     for now; items don't carry a floor/location tag yet (see README). */
  const [menuItems, setMenuItems] = useState([]);
  const [menuLoading, setMenuLoading] = useState(true);
  const [menuCategory, setMenuCategory] = useState(null); // set to the first live category once the menu loads

  /* Live site content — Realtime Database /site_content. Edited by the owner
     via the Tavern Console's "Site Content" tab (hero copy, floor
     descriptions, potions, contact info, social handles, store items).
     Starts as DEFAULT_CONTENT so the page renders immediately, then swaps
     in real values once the fetch resolves. */
  const [siteContent, setSiteContent] = useState(DEFAULT_CONTENT);

  const [bookingForm, setBookingForm] = useState({
    floor: "Main Hall", date: "", time: "", party: "2", name: "", phone: "", notes: "",
  });
  const [bookingSubmitting, setBookingSubmitting] = useState(false);
  const [bookingError, setBookingError] = useState("");
  const [bookingSubmitted, setBookingSubmitted] = useState(false);
  const [bookingRef, setBookingRef] = useState("");

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      setScrollPct(max > 0 ? Math.min(100, (h.scrollTop / max) * 100) : 0);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* Load events from Firestore huntboard/events (same doc the console's
     Quest Board tab writes to). Falls back to an empty calendar if the
     doc doesn't exist yet or the read fails — no fictional placeholder
     events are shown. */
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const snap = await getDoc(doc(db, "huntboard", "events"));
        const items = snap.exists() ? (snap.data().items || []) : [];
        const byDate = {};
        items.forEach((ev) => {
          const key = ev.dateISO || ev.date;
          if (!key) return;
          if (!byDate[key]) byDate[key] = [];
          byDate[key].push({
            time: ev.time || "",
            title: ev.title || "Untitled event",
            desc: ev.description || "",
            emoji: ev.emoji || "🎉",
            fee: ev.fee || "",
            bookable: !!ev.bookable,
          });
        });
        if (active) setEvents(byDate);
      } catch (e) {
        console.error("Failed to load events from huntboard/events", e);
      } finally {
        if (active) setEventsLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  /* Load the weekly schedule from Firestore huntboard/schedules (the same
     doc the console's Quest Board "Schedule" tab writes to). Falls back to
     an empty list if the doc doesn't exist yet or the read fails — no
     invented placeholder schedule is shown. */
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const snap = await getDoc(doc(db, "huntboard", "schedules"));
        const items = snap.exists() ? (snap.data().items || []) : [];
        const rows = items
          .map((s) => ({ day: s.day || "", title: s.title || "", time: s.time || "" }))
          .filter((s) => s.day || s.title);
        if (active) setSchedule(rows);
      } catch (e) {
        console.error("Failed to load schedule from huntboard/schedules", e);
      } finally {
        if (active) setScheduleLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  /* Load menu from Realtime Database /menu (same node the console's Menu
     Manager edits). Unavailable items are filtered out. */
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const snap = await rtdbGet(ref(rtdb, "menu"));
        const raw = snap.exists() ? snap.val() : {};
        const items = Object.values(raw || {})
          .filter((i) => i && i.isAvailable !== false)
          .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
        if (active) setMenuItems(items);
      } catch (e) {
        console.error("Failed to load menu from RTDB /menu", e);
      } finally {
        if (active) setMenuLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  /* Load site content from Realtime Database /site_content (same node the
     console's Site Content tab writes to via a flat-JSON PUT). Merges onto
     DEFAULT_CONTENT field-by-field so a partially-filled-in doc — or no doc
     at all yet — never blanks out a section of the site. */
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const snap = await rtdbGet(ref(rtdb, "site_content"));
        const raw = snap.exists() ? snap.val() : null;
        if (raw && active) {
          setSiteContent({
            hero: { ...DEFAULT_CONTENT.hero, ...(raw.hero || {}) },
            floors: { ...DEFAULT_CONTENT.floors, ...(raw.floors || {}) },
            potionsIntro: raw.potionsIntro || DEFAULT_CONTENT.potionsIntro,
            potionsPrice: typeof raw.potionsPrice === "number" ? raw.potionsPrice : DEFAULT_CONTENT.potionsPrice,
            potions: Array.isArray(raw.potions) && raw.potions.length ? raw.potions : DEFAULT_CONTENT.potions,
            contact: { ...DEFAULT_CONTENT.contact, ...(raw.contact || {}) },
            social: { ...DEFAULT_CONTENT.social, ...(raw.social || {}) },
            store: Array.isArray(raw.store) && raw.store.length ? raw.store : DEFAULT_CONTENT.store,
            sectionOrder: isValidSectionOrder(raw.sectionOrder) ? raw.sectionOrder : DEFAULT_SECTION_ORDER,
            sectionMeta: mergeSectionMeta(raw.sectionMeta),
            theme: { ...DEFAULT_CONTENT.theme, ...(raw.theme || {}) },
            brand: { ...DEFAULT_CONTENT.brand, ...(raw.brand || {}) },
            buttons: { ...DEFAULT_CONTENT.buttons, ...(raw.buttons || {}) },
            background: mergeBackground(raw.background),
          });
        }
      } catch (e) {
        console.error("Failed to load site content from RTDB /site_content — showing defaults", e);
      }
    })();
    return () => { active = false; };
  }, []);

  /* Themed accent colors — owner-editable via the console's Theme panel.
     This *shadows* the module-level BASE_C for the rest of this component,
     so every existing `C.xxx` reference below (buttons, section labels,
     borders, glows) automatically picks up the live theme with no other
     changes needed. */
  const C = useMemo(() => ({ ...BASE_C, ...siteContent.theme }), [siteContent.theme]);

  /* Store items shown in the Store grid — from live content, icon strings
     resolved back to lucide components. */
  const storeItems = useMemo(
    () => (siteContent.store || []).map((p) => ({ ...p, IconComp: ICON_MAP[p.icon] || Layers })),
    [siteContent.store]
  );

  /* The Potions section's ticket, priced from siteContent.potionsPrice.
     Kept as its own synthetic cart line (not part of the Store grid) so the
     owner doesn't have to duplicate it in the store list. */
  const potionTicket = useMemo(
    () => ({ id: "potions-ticket", name: "Potion-Making Experience", price: siteContent.potionsPrice }),
    [siteContent.potionsPrice]
  );

  /* Section order — owner-editable via the console's drag-and-drop reorder
     list. "home" (hero) is always first, the footer is always last; only
     the seven sections in between move. */
  const sectionOrder = isValidSectionOrder(siteContent.sectionOrder) ? siteContent.sectionOrder : DEFAULT_SECTION_ORDER;

  /* Sections the owner has hidden (console's Site Content tab) are dropped
     here — from both the nav and the actual render loop below — while
     staying in sectionOrder so their position is remembered if re-shown. */
  const visibleSectionOrder = useMemo(
    () => sectionOrder.filter((id) => !(siteContent.sectionMeta?.[id]?.hidden)),
    [sectionOrder, siteContent.sectionMeta]
  );

  const navItems = useMemo(
    () => [{ id: "home", label: "Home" }, ...visibleSectionOrder.map((id) => ({ id, label: SECTION_META[id].label }))],
    [visibleSectionOrder]
  );

  /* Scroll-spy — depends on navItems so it re-observes if the section order
     changes (i.e. once real siteContent.sectionOrder loads in). */
  useEffect(() => {
    const sections = navItems.map((n) => document.getElementById(n.id)).filter(Boolean);
    if (sections.length === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveSection(entry.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, [navItems]);

  const menuCategories = useMemo(() => {
    const seen = [];
    menuItems.forEach((i) => {
      if (i.category && !seen.includes(i.category)) seen.push(i.category);
    });
    return seen;
  }, [menuItems]);

  /* The menu is split into switchable categories — only one category's
     items show at a time, and its title acts as the tab. Defaults to the
     first category once the live menu loads, and re-picks a valid one if
     the current selection disappears (e.g. that category's items all sell
     out/get unpublished). Items with no category (or if the menu has none
     at all) just show as one flat list — nothing to switch between. */
  useEffect(() => {
    if (menuCategories.length > 0 && !menuCategories.includes(menuCategory)) {
      setMenuCategory(menuCategories[0]);
    }
  }, [menuCategories, menuCategory]);

  const visibleMenuItems = useMemo(() => {
    if (menuCategories.length === 0) return menuItems;
    return menuItems.filter((i) => i.category === menuCategory);
  }, [menuItems, menuCategory, menuCategories]);

  const scrollTo = (id) => {
    setMenuOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const findProduct = (id) => storeItems.find((p) => p.id === id) || (id === potionTicket.id ? potionTicket : null);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cart.reduce((s, i) => {
    const p = findProduct(i.id);
    return s + (p ? p.price * i.qty : 0);
  }, 0);

  const addToCart = (id) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === id);
      if (existing) return prev.map((i) => (i.id === id ? { ...i, qty: i.qty + 1 } : i));
      return [...prev, { id, qty: 1 }];
    });
    setCartOpen(true);
  };

  const changeQty = (id, delta) => {
    setCart((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, qty: i.qty + delta } : i))
        .filter((i) => i.qty > 0)
    );
  };

  const placeOrder = (e) => {
    e.preventDefault();
    // Store checkout stays mock for now — there's no merch/ticket
    // inventory source in the Kingdom backend yet (see README).
    const ref = "TVN-" + Math.random().toString(36).slice(2, 8).toUpperCase();
    setOrderRef(ref);
    setCheckoutStep("success");
  };

  const resetCart = () => {
    setCart([]);
    setCheckoutStep("cart");
    setCheckoutForm({ name: "", email: "" });
    setCartOpen(false);
  };

  /* Real reservation write into Firestore /bookings — the same
     collection the console's Bookings tab reads and manages
     (pending → confirm → seat → cancel/no-show). */
  const submitBooking = async (e) => {
    e.preventDefault();
    setBookingSubmitting(true);
    setBookingError("");
    const displayRef = "RSV-" + Math.random().toString(36).slice(2, 7).toUpperCase();
    try {
      if (!auth.currentUser) {
        await signInAnonymously(auth);
      }
      await addDoc(collection(db, "bookings"), {
        guestName: bookingForm.name,
        phone: bookingForm.phone,
        floor: bookingForm.floor,
        date: bookingForm.date,
        time: bookingForm.time,
        partySize: parseInt(bookingForm.party, 10) || 1,
        note: bookingForm.notes || "",
        status: "pending",
        reminderSent: false,
        source: "website",
        displayRef,
        uid: auth.currentUser ? auth.currentUser.uid : null,
        createdAt: serverTimestamp(),
      });
      setBookingRef(displayRef);
      setBookingSubmitted(true);
    } catch (err) {
      console.error("Failed to submit booking", err);
      setBookingError("Couldn't submit your reservation — please try again, or call us directly.");
    } finally {
      setBookingSubmitting(false);
    }
  };

  /* Calendar grid */
  const calGrid = useMemo(() => {
    const year = calMonth.getFullYear();
    const month = calMonth.getMonth();
    const firstDow = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells = [];
    for (let i = 0; i < firstDow; i++) cells.push(null);
    for (let d = 1; d <= daysInMonth; d++) {
      const key = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      cells.push({ day: d, key });
    }
    return cells;
  }, [calMonth]);

  const selectedEvents = events[selectedDate] || [];

  return (
    <div style={{ ...body, background: C.oak, color: C.cream }} className="min-h-screen w-full">
      <style>{`
        ${FONT_IMPORT}
        html { scroll-behavior: smooth; }
        * { box-sizing: border-box; }
        ::selection { background: ${C.brass}; color: ${C.oakDeep}; }
        @media (prefers-reduced-motion: reduce) {
          html { scroll-behavior: auto; }
        }
        .focus-ring:focus-visible {
          outline: 2px solid ${C.brassBright};
          outline-offset: 2px;
        }
      `}</style>

      <StairRail progress={scrollPct} theme={C} />

      {/* NAV */}
      <header
        className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-5 md:px-10 py-4"
        style={{ background: "rgba(18,14,10,0.88)", backdropFilter: "blur(6px)", borderBottom: `1px solid rgba(185,139,62,0.25)` }}
      >
        <button onClick={() => scrollTo("home")} className="focus-ring" style={{ ...display, fontSize: 18, letterSpacing: "0.08em", color: C.brassBright, background: "none", border: "none", cursor: "pointer" }}>
          {siteContent.brand.name}
        </button>
        <nav className="hidden lg:flex items-center gap-7">
          {navItems.slice(1).map((n) => {
            const isActive = activeSection === n.id;
            return (
              <button
                key={n.id}
                onClick={() => scrollTo(n.id)}
                className="focus-ring relative"
                style={{
                  ...mono, fontSize: 12, letterSpacing: "0.1em",
                  color: isActive ? C.brassBright : C.parchmentDim,
                  background: "none", border: "none", cursor: "pointer",
                  paddingBottom: 4,
                  transition: "color 0.15s ease",
                }}
              >
                {n.label.toUpperCase()}
                <span
                  style={{
                    position: "absolute", left: 0, right: 0, bottom: -2, height: 1,
                    background: C.brassBright,
                    transform: isActive ? "scaleX(1)" : "scaleX(0)",
                    transition: "transform 0.2s ease",
                  }}
                />
              </button>
            );
          })}
        </nav>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCartOpen(true)}
            className="focus-ring relative flex items-center gap-1 px-3 py-2 rounded"
            style={{ border: `1px solid ${C.brass}`, background: "transparent", color: C.brassBright, cursor: "pointer" }}
          >
            <ShoppingCart size={16} />
            <span style={{ ...mono, fontSize: 12 }}>{cartCount}</span>
          </button>
          <button
            className="lg:hidden focus-ring"
            onClick={() => setMenuOpen((v) => !v)}
            style={{ background: "none", border: "none", color: C.cream, cursor: "pointer" }}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      {menuOpen && (
        <div className="lg:hidden fixed top-[64px] left-0 right-0 z-40 flex flex-col px-6 py-4 gap-3" style={{ background: C.oakDeep, borderBottom: `1px solid rgba(185,139,62,0.3)` }}>
          {navItems.slice(1).map((n) => (
            <button key={n.id} onClick={() => scrollTo(n.id)} className="text-left focus-ring" style={{ ...mono, fontSize: 13, color: activeSection === n.id ? C.brassBright : C.parchmentDim, background: "none", border: "none", padding: "8px 0" }}>
              {activeSection === n.id ? "→ " : ""}{n.label}
            </button>
          ))}
        </div>
      )}

      {/* HERO */}
      <SectionBackdrop
        id="home"
        className="relative flex flex-col items-center justify-center text-center px-6 pt-32 pb-24 min-h-screen"
        fallback={`radial-gradient(ellipse at 50% 20%, #2A2016 0%, ${C.oak} 45%, ${C.oakDeep} 100%)`}
        bg={siteContent.background.hero}
      >
        <SectionLabel color={C.brass}>{siteContent.hero.label}</SectionLabel>
        <h1 style={{ ...display, fontSize: "clamp(2.6rem, 7vw, 6rem)", lineHeight: 1.02, color: C.parchment, fontWeight: 700 }}>
          {siteContent.hero.headline}
        </h1>
        <p style={{ ...body, fontStyle: "italic", fontSize: "clamp(1.05rem, 2vw, 1.35rem)", color: C.parchmentDim, maxWidth: 560, marginTop: 20 }}>
          {siteContent.hero.tagline}
        </p>
        <div className="flex flex-wrap gap-4 justify-center mt-10">
          <button onClick={() => scrollTo("book")} className="focus-ring" style={{ ...mono, fontSize: 13, letterSpacing: "0.06em", background: C.ember, color: C.cream, padding: "14px 28px", border: "none", borderRadius: 4, cursor: "pointer" }}>
            {siteContent.buttons.reserveTable}
          </button>
          <button onClick={() => scrollTo("menu")} className="focus-ring" style={{ ...mono, fontSize: 13, letterSpacing: "0.06em", background: "transparent", color: C.brassBright, padding: "14px 28px", border: `1px solid ${C.brass}`, borderRadius: 4, cursor: "pointer" }}>
            {siteContent.buttons.viewMenu}
          </button>
        </div>
        <div className="mt-20 flex items-center gap-2" style={{ color: C.brass, opacity: 0.7 }}>
          <div style={{ width: 1, height: 40, background: "linear-gradient(to bottom, transparent, currentColor)" }} />
        </div>
      </SectionBackdrop>

      {/* Reorderable sections — owner-controlled order via the console's
          drag-and-drop Site Content editor (siteContent.sectionOrder). Each
          section's JSX lives in this lookup so it can be rendered in any
          order without duplicating markup. */}
      {(() => {
        const sectionMarkup = {
          floors: (
            <SectionBackdrop id="floors" className="px-6 md:px-10 py-24" fallback={C.oakDeep} bg={siteContent.background.floors}>
              <div className="max-w-6xl mx-auto">
                <SectionLabel color={C.brass}>{siteContent.sectionMeta.floors.label}</SectionLabel>
                <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: C.parchment, marginBottom: 16 }}>
                  {siteContent.sectionMeta.floors.heading}
                </h2>
                <div className="grid md:grid-cols-2 gap-6 mt-10">
                  <div className="p-8 rounded" style={{ background: "rgba(185,139,62,0.06)", border: `1px solid rgba(185,139,62,0.25)` }}>
                    <span style={{ ...mono, fontSize: 11, color: C.brass, letterSpacing: "0.15em" }}>GROUND FLOOR — ALL AGES</span>
                    <h3 style={{ ...display, fontSize: 26, color: C.parchment, margin: "12px 0" }}>The Main Hall</h3>
                    <p style={{ color: C.parchmentDim, lineHeight: 1.7 }}>
                      {siteContent.floors.mainHallDesc}
                    </p>
                  </div>
                  <div className="p-8 rounded" style={{ background: "rgba(143,199,158,0.06)", border: `1px solid rgba(143,199,158,0.25)` }}>
                    <span style={{ ...mono, fontSize: 11, color: C.alchemyGlow, letterSpacing: "0.15em" }}>UPSTAIRS — 21+</span>
                    <h3 style={{ ...display, fontSize: 26, color: C.parchment, margin: "12px 0" }}>Alchemy House</h3>
                    <p style={{ color: C.parchmentDim, lineHeight: 1.7 }}>
                      {siteContent.floors.alchemyDesc}
                    </p>
                  </div>
                </div>
              </div>
            </SectionBackdrop>
          ),

          menu: (
            <SectionBackdrop id="menu" className="px-6 md:px-10 py-24" fallback={C.oak} bg={siteContent.background.menu}>
              <div className="max-w-5xl mx-auto">
                <SectionLabel color={C.brass}>{siteContent.sectionMeta.menu.label}</SectionLabel>
                <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: C.parchment }}>{siteContent.sectionMeta.menu.heading}</h2>

                {menuLoading ? (
                  <p style={{ color: C.parchmentDim, opacity: 0.7, marginTop: 24 }}>Loading the menu…</p>
                ) : menuItems.length === 0 ? (
                  <p style={{ color: C.parchmentDim, opacity: 0.7, marginTop: 24 }}>The menu isn't published yet — check back soon.</p>
                ) : (
                  <>
                    {menuCategories.length > 0 && (
                      <div className="flex flex-wrap gap-6 mt-10 mb-8" style={{ borderBottom: "1px solid rgba(185,139,62,0.18)" }}>
                        {menuCategories.map((cat) => {
                          const isActive = menuCategory === cat;
                          return (
                            <button
                              key={cat}
                              onClick={() => setMenuCategory(cat)}
                              className="focus-ring relative"
                              style={{
                                ...display, fontSize: "clamp(1rem, 1.6vw, 1.3rem)", letterSpacing: "0.03em",
                                background: "none", border: "none", cursor: "pointer", padding: "0 0 14px",
                                color: isActive ? C.brassBright : C.parchmentDim,
                                opacity: isActive ? 1 : 0.55,
                                transition: "color 0.15s ease, opacity 0.15s ease",
                              }}
                            >
                              {cat}
                              <span
                                style={{
                                  position: "absolute", left: 0, right: 0, bottom: -1, height: 2,
                                  background: C.brassBright,
                                  transform: isActive ? "scaleX(1)" : "scaleX(0)",
                                  transition: "transform 0.2s ease",
                                }}
                              />
                            </button>
                          );
                        })}
                      </div>
                    )}
                    <div className="grid sm:grid-cols-2 gap-x-10">
                      {visibleMenuItems.map((item, idx) => (
                        <div key={item.name || idx} className="flex justify-between items-baseline py-4" style={{ borderBottom: "1px solid rgba(185,139,62,0.18)" }}>
                          <div className="pr-4">
                            <div style={{ ...body, fontSize: 17, color: C.parchment }}>{item.name}</div>
                            {item.description && (
                              <div style={{ fontSize: 13.5, color: C.parchmentDim, marginTop: 4, opacity: 0.85 }}>{item.description}</div>
                            )}
                            <div className="flex flex-wrap gap-1 mt-2">
                              {DIET_BADGES.filter((b) => item[b.key]).map((b) => (
                                <span key={b.key} style={{ ...mono, fontSize: 9, letterSpacing: "0.05em", color: b.color, border: `1px solid ${b.color}`, borderRadius: 3, padding: "1px 5px" }}>
                                  {b.label}
                                </span>
                              ))}
                            </div>
                          </div>
                          <div style={{ ...mono, fontSize: 14, color: C.brassBright, whiteSpace: "nowrap" }}>{fmt(item.price)}</div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </SectionBackdrop>
          ),

          events: (
            <SectionBackdrop id="events" className="px-6 md:px-10 py-24" fallback={C.oakDeep} bg={siteContent.background.events}>
              <div className="max-w-5xl mx-auto">
                <SectionLabel color={C.brass}>{siteContent.sectionMeta.events.label}</SectionLabel>
                <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: C.parchment, marginBottom: 32 }}>
                  {siteContent.sectionMeta.events.heading}
                </h2>
                <div className="grid md:grid-cols-2 gap-8">
                  {/* Calendar grid */}
                  <div className="p-6 rounded" style={{ background: "rgba(185,139,62,0.05)", border: "1px solid rgba(185,139,62,0.2)" }}>
                    <div className="flex items-center justify-between mb-5">
                      <button
                        className="focus-ring"
                        onClick={() => setCalMonth(new Date(calMonth.getFullYear(), calMonth.getMonth() - 1, 1))}
                        style={{ background: "none", border: "none", color: C.brassBright, cursor: "pointer" }}
                        aria-label="Previous month"
                      >
                        <ChevronLeft size={20} />
                      </button>
                      <span style={{ ...display, fontSize: 18, color: C.parchment }}>
                        {MONTH_NAMES[calMonth.getMonth()]} {calMonth.getFullYear()}
                      </span>
                      <button
                        className="focus-ring"
                        onClick={() => setCalMonth(new Date(calMonth.getFullYear(), calMonth.getMonth() + 1, 1))}
                        style={{ background: "none", border: "none", color: C.brassBright, cursor: "pointer" }}
                        aria-label="Next month"
                      >
                        <ChevronRight size={20} />
                      </button>
                    </div>
                    <div className="grid grid-cols-7 gap-1 mb-2">
                      {DOW.map((d, i) => (
                        <div key={i} style={{ ...mono, fontSize: 11, textAlign: "center", color: C.parchmentDim, opacity: 0.6 }}>{d}</div>
                      ))}
                    </div>
                    <div className="grid grid-cols-7 gap-1">
                      {calGrid.map((cell, i) => {
                        if (!cell) return <div key={i} />;
                        const hasEvent = !!events[cell.key];
                        const isSelected = cell.key === selectedDate;
                        return (
                          <button
                            key={i}
                            onClick={() => setSelectedDate(cell.key)}
                            className="focus-ring"
                            style={{
                              aspectRatio: "1",
                              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                              borderRadius: 4, cursor: "pointer", border: isSelected ? `1px solid ${C.brassBright}` : "1px solid transparent",
                              background: isSelected ? "rgba(185,139,62,0.18)" : "transparent",
                              color: C.parchment,
                            }}
                          >
                            <span style={{ ...mono, fontSize: 12 }}>{cell.day}</span>
                            {hasEvent && <span style={{ width: 4, height: 4, borderRadius: "50%", background: C.brassBright, marginTop: 3 }} />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Selected day detail */}
                  <div className="p-6 rounded" style={{ background: "rgba(185,139,62,0.05)", border: "1px solid rgba(185,139,62,0.2)" }}>
                    <div className="flex items-center gap-2 mb-4" style={{ color: C.brassBright }}>
                      <CalendarDays size={16} />
                      <span style={{ ...mono, fontSize: 12 }}>{selectedDate}</span>
                    </div>
                    {eventsLoading ? (
                      <p style={{ color: C.parchmentDim, fontSize: 14, opacity: 0.7 }}>Loading events…</p>
                    ) : selectedEvents.length === 0 ? (
                      <p style={{ color: C.parchmentDim, fontSize: 14, opacity: 0.7 }}>No events scheduled. Select a marked date to see what's on.</p>
                    ) : (
                      <div className="flex flex-col gap-5">
                        {selectedEvents.map((ev, i) => (
                          <div key={i}>
                            <div className="flex items-center gap-2 mb-1" style={{ color: C.brassBright }}>
                              <span style={{ fontSize: 15 }}>{ev.emoji}</span>
                              <span style={{ ...mono, fontSize: 11, letterSpacing: "0.08em" }}>{ev.time}</span>
                              {ev.bookable && (
                                <span style={{ ...mono, fontSize: 9, letterSpacing: "0.05em", color: C.alchemyGlow, border: `1px solid ${C.alchemyGlow}`, borderRadius: 3, padding: "1px 5px" }}>
                                  BOOKABLE
                                </span>
                              )}
                            </div>
                            <div style={{ ...body, fontSize: 16, color: C.parchment }}>{ev.title}</div>
                            <p style={{ fontSize: 13.5, color: C.parchmentDim, marginTop: 6, opacity: 0.85 }}>{ev.desc}</p>
                            {ev.fee && (
                              <p style={{ ...mono, fontSize: 12, color: C.brassBright, marginTop: 4 }}>{ev.fee}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </SectionBackdrop>
          ),

          // SCHEDULE — recurring weekly rundown from Firestore
          // huntboard/schedules (the console's Quest Board "Schedule" tab).
          // Separate from the Events calendar above: this is a fixed
          // day-of-week list, not tied to specific dates.
          schedule: (
            <SectionBackdrop id="schedule" className="px-6 md:px-10 py-24" fallback={C.oak} bg={siteContent.background.schedule}>
              <div className="max-w-4xl mx-auto">
                <SectionLabel color={C.brass}>{siteContent.sectionMeta.schedule.label}</SectionLabel>
                <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: C.parchment, marginBottom: 32 }}>
                  {siteContent.sectionMeta.schedule.heading}
                </h2>
                {scheduleLoading ? (
                  <p style={{ color: C.parchmentDim, opacity: 0.7 }}>Loading the schedule…</p>
                ) : schedule.length === 0 ? (
                  <p style={{ color: C.parchmentDim, opacity: 0.7 }}>The weekly schedule isn't published yet — check back soon.</p>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-4">
                    {schedule.map((s, i) => (
                      <div key={i} className="flex items-center justify-between gap-4 p-4 rounded" style={{ background: "rgba(185,139,62,0.05)", border: "1px solid rgba(185,139,62,0.2)" }}>
                        <div>
                          <div style={{ ...mono, fontSize: 10, color: C.brass, letterSpacing: "0.12em" }}>{s.day.toUpperCase()}</div>
                          <div style={{ ...body, fontSize: 16, color: C.parchment, marginTop: 4 }}>{s.title}</div>
                        </div>
                        <div style={{ ...mono, fontSize: 12, color: C.brassBright, whiteSpace: "nowrap" }}>{s.time}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </SectionBackdrop>
          ),

          potions: (
            <SectionBackdrop id="potions" className="px-6 md:px-10 py-28" fallback={`radial-gradient(ellipse at 50% 0%, ${C.alchemy} 0%, ${C.alchemyDeep} 60%)`} bg={siteContent.background.potions}>
              <div className="max-w-5xl mx-auto text-center">
                <SectionLabel color={C.alchemyGlow}>{siteContent.sectionMeta.potions.label}</SectionLabel>
                <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: C.cream }}>{siteContent.sectionMeta.potions.heading}</h2>
                <p style={{ color: "#CFE0D2", maxWidth: 560, margin: "16px auto 0", lineHeight: 1.7 }}>
                  {siteContent.potionsIntro}
                </p>
                <div className="grid sm:grid-cols-3 gap-6 mt-14">
                  {siteContent.potions.map((p, i) => (
                    <div key={i} className="p-6 rounded" style={{ background: "rgba(143,199,158,0.08)", border: "1px solid rgba(143,199,158,0.25)" }}>
                      <FlaskConical size={22} color={C.alchemyGlow} />
                      <div style={{ ...display, fontSize: 18, color: C.cream, marginTop: 12 }}>{p.name}</div>
                      <div style={{ fontSize: 13, color: "#CFE0D2", marginTop: 6, opacity: 0.85 }}>{p.note}</div>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => addToCart(potionTicket.id)}
                  className="focus-ring mt-12"
                  style={{ ...mono, fontSize: 13, letterSpacing: "0.06em", background: C.alchemyGlow, color: C.alchemyDeep, padding: "14px 28px", border: "none", borderRadius: 4, cursor: "pointer" }}
                >
                  {siteContent.buttons.addTicket} · {fmt(siteContent.potionsPrice)}
                </button>
              </div>
            </SectionBackdrop>
          ),

          // STORE — live from RTDB /site_content.store (owner-edited via the
          // console's Site Content tab). Checkout itself stays mock — there's
          // no payment processor connected yet (see README).
          store: (
            <SectionBackdrop id="store" className="px-6 md:px-10 py-24" fallback={C.oak} bg={siteContent.background.store}>
              <div className="max-w-6xl mx-auto">
                <SectionLabel color={C.brass}>{siteContent.sectionMeta.store.label}</SectionLabel>
                <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: C.parchment, marginBottom: 32 }}>{siteContent.sectionMeta.store.heading}</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {storeItems.map((p) => {
                    const Icon = p.IconComp;
                    return (
                      <div key={p.id} className="p-5 rounded flex flex-col" style={{ background: "rgba(185,139,62,0.05)", border: "1px solid rgba(185,139,62,0.2)" }}>
                        {p.imageUrl ? (
                          <img src={p.imageUrl} alt={p.name} className="w-full h-28 object-cover rounded" style={{ marginBottom: 4 }} />
                        ) : (
                          <Icon size={20} color={C.brassBright} />
                        )}
                        <span style={{ ...mono, fontSize: 10, color: C.brass, letterSpacing: "0.1em", marginTop: 12 }}>{p.cat.toUpperCase()}</span>
                        <div style={{ ...body, fontSize: 16, color: C.parchment, marginTop: 6 }}>{p.name}</div>
                        <p style={{ fontSize: 12.5, color: C.parchmentDim, marginTop: 6, opacity: 0.8, flexGrow: 1 }}>{p.desc}</p>
                        <div className="flex items-center justify-between mt-5">
                          <span style={{ ...mono, fontSize: 13, color: C.brassBright }}>{fmt(p.price)}</span>
                          <button
                            onClick={() => addToCart(p.id)}
                            className="focus-ring"
                            style={{ ...mono, fontSize: 11, letterSpacing: "0.05em", background: "transparent", border: `1px solid ${C.brass}`, color: C.brassBright, padding: "7px 12px", borderRadius: 4, cursor: "pointer" }}
                          >
                            ADD
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </SectionBackdrop>
          ),

          // BOOKING — writes a real document into Firestore /bookings
          book: (
            <SectionBackdrop id="book" className="px-6 md:px-10 py-24" fallback={C.oakDeep} bg={siteContent.background.book}>
              <div className="max-w-2xl mx-auto">
                <SectionLabel color={C.brass}>{siteContent.sectionMeta.book.label}</SectionLabel>
                <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: C.parchment, marginBottom: 8 }}>{siteContent.sectionMeta.book.heading}</h2>
                <p style={{ color: C.parchmentDim, marginBottom: 32, opacity: 0.85 }}>Choose your floor. Alchemy House seating is 21+.</p>

                {bookingSubmitted ? (
                  <div className="p-8 rounded text-center" style={{ background: "rgba(185,139,62,0.08)", border: `1px solid ${C.brass}` }}>
                    <Check size={28} color={C.brassBright} className="mx-auto" />
                    <h3 style={{ ...display, fontSize: 22, color: C.parchment, marginTop: 14 }}>Reservation held</h3>
                    <p style={{ color: C.parchmentDim, marginTop: 8 }}>
                      {bookingForm.party} guest{bookingForm.party !== "1" ? "s" : ""} · {bookingForm.floor} · {bookingForm.date || "date pending"} at {bookingForm.time || "time pending"}
                    </p>
                    <p style={{ ...mono, fontSize: 12, color: C.brassBright, marginTop: 10 }}>REFERENCE {bookingRef}</p>
                    <button
                      onClick={() => { setBookingSubmitted(false); setBookingForm({ floor: "Main Hall", date: "", time: "", party: "2", name: "", phone: "", notes: "" }); }}
                      className="focus-ring mt-6"
                      style={{ ...mono, fontSize: 12, background: "transparent", border: `1px solid ${C.brass}`, color: C.brassBright, padding: "10px 18px", borderRadius: 4, cursor: "pointer" }}
                    >
                      BOOK ANOTHER TABLE
                    </button>
                  </div>
                ) : (
                  <form onSubmit={submitBooking} className="flex flex-col gap-5">
                    <div className="grid grid-cols-2 gap-3">
                      {["Main Hall", "Alchemy House (21+)"].map((f) => (
                        <button
                          type="button"
                          key={f}
                          onClick={() => setBookingForm({ ...bookingForm, floor: f })}
                          className="focus-ring"
                          style={{
                            ...mono, fontSize: 12, padding: "12px", borderRadius: 4, cursor: "pointer",
                            border: `1px solid ${bookingForm.floor === f ? C.brassBright : "rgba(185,139,62,0.3)"}`,
                            background: bookingForm.floor === f ? "rgba(185,139,62,0.15)" : "transparent",
                            color: bookingForm.floor === f ? C.brassBright : C.parchmentDim,
                          }}
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="flex flex-col gap-1">
                        <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>DATE</span>
                        <input required type="date" value={bookingForm.date} onChange={(e) => setBookingForm({ ...bookingForm, date: e.target.value })}
                          className="focus-ring" style={inputStyle} />
                      </label>
                      <label className="flex flex-col gap-1">
                        <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>TIME</span>
                        <input required type="time" value={bookingForm.time} onChange={(e) => setBookingForm({ ...bookingForm, time: e.target.value })}
                          className="focus-ring" style={inputStyle} />
                      </label>
                    </div>
                    <label className="flex flex-col gap-1">
                      <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>PARTY SIZE</span>
                      <select value={bookingForm.party} onChange={(e) => setBookingForm({ ...bookingForm, party: e.target.value })} className="focus-ring" style={inputStyle}>
                        {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => <option key={n} value={n}>{n}</option>)}
                      </select>
                    </label>
                    <label className="flex flex-col gap-1">
                      <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>NAME</span>
                      <input required value={bookingForm.name} onChange={(e) => setBookingForm({ ...bookingForm, name: e.target.value })} className="focus-ring" style={inputStyle} />
                    </label>
                    <label className="flex flex-col gap-1">
                      <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>PHONE</span>
                      <input required value={bookingForm.phone} onChange={(e) => setBookingForm({ ...bookingForm, phone: e.target.value })} className="focus-ring" style={inputStyle} />
                    </label>
                    <label className="flex flex-col gap-1">
                      <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>NOTES (OPTIONAL)</span>
                      <textarea rows={3} value={bookingForm.notes} onChange={(e) => setBookingForm({ ...bookingForm, notes: e.target.value })} className="focus-ring" style={{ ...inputStyle, resize: "vertical" }} />
                    </label>
                    {bookingError && (
                      <p style={{ ...mono, fontSize: 12, color: C.emberBright }}>{bookingError}</p>
                    )}
                    <button type="submit" disabled={bookingSubmitting} className="focus-ring" style={{ ...mono, fontSize: 13, letterSpacing: "0.06em", background: C.ember, color: C.cream, padding: "14px 28px", border: "none", borderRadius: 4, cursor: bookingSubmitting ? "default" : "pointer", opacity: bookingSubmitting ? 0.7 : 1 }}>
                      {bookingSubmitting ? "SUBMITTING…" : "CONFIRM RESERVATION"}
                    </button>
                  </form>
                )}
              </div>
            </SectionBackdrop>
          ),

          visit: (
            <SectionBackdrop id="visit" className="px-6 md:px-10 py-24" fallback={C.oak} bg={siteContent.background.visit}>
              <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12">
                <div>
                  <SectionLabel color={C.brass}>{siteContent.sectionMeta.visit.label}</SectionLabel>
                  <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", color: C.parchment, marginBottom: 20 }}>{siteContent.sectionMeta.visit.heading}</h2>
                  <div className="flex items-start gap-3 mb-4">
                    <MapPin size={18} color={C.brassBright} className="mt-1 flex-shrink-0" />
                    <span style={{ color: C.parchmentDim }}>{siteContent.contact.address}</span>
                  </div>
                  <div className="flex items-start gap-3 mb-4">
                    <Clock size={18} color={C.brassBright} className="mt-1 flex-shrink-0" />
                    <div style={{ color: C.parchmentDim }}>
                      <div>Main Hall — {siteContent.contact.hoursMainHall}</div>
                      <div>Alchemy House — {siteContent.contact.hoursAlchemy}</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone size={18} color={C.brassBright} className="mt-1 flex-shrink-0" />
                    <span style={{ color: C.parchmentDim }}>{siteContent.contact.phone}</span>
                  </div>
                </div>
                <div>
                  <SectionLabel color={C.brass}>{siteContent.sectionMeta.visit.label2}</SectionLabel>
                  <h2 style={{ ...display, fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", color: C.parchment, marginBottom: 20 }}>{siteContent.sectionMeta.visit.heading2}</h2>
                  <div className="p-5 rounded mb-4" style={{ border: "1px solid rgba(185,139,62,0.25)" }}>
                    {siteContent.social.tavernUrl ? (
                      <a href={siteContent.social.tavernUrl} target="_blank" rel="noopener noreferrer" style={{ ...mono, fontSize: 12, color: C.brassBright, textDecoration: "none" }}>{siteContent.social.tavernHandle}</a>
                    ) : (
                      <div style={{ ...mono, fontSize: 12, color: C.brassBright }}>{siteContent.social.tavernHandle}</div>
                    )}
                    <div style={{ fontSize: 13, color: C.parchmentDim, marginTop: 4, opacity: 0.85 }}>Family floor, meals, D&D & MTG nights</div>
                  </div>
                  <div className="p-5 rounded" style={{ border: "1px solid rgba(143,199,158,0.3)" }}>
                    {siteContent.social.alchemyUrl ? (
                      <a href={siteContent.social.alchemyUrl} target="_blank" rel="noopener noreferrer" style={{ ...mono, fontSize: 12, color: C.alchemyGlow, textDecoration: "none" }}>{siteContent.social.alchemyHandle}</a>
                    ) : (
                      <div style={{ ...mono, fontSize: 12, color: C.alchemyGlow }}>{siteContent.social.alchemyHandle}</div>
                    )}
                    <div style={{ fontSize: 13, color: C.parchmentDim, marginTop: 4, opacity: 0.85 }}>Alchemy House · by The Tavern</div>
                  </div>
                </div>
              </div>
            </SectionBackdrop>
          ),
        };

        return visibleSectionOrder.map((id) => (
          <React.Fragment key={id}>{sectionMarkup[id]}</React.Fragment>
        ));
      })()}

      {/* FOOTER */}
      <footer className="px-6 md:px-10 py-10 flex flex-col md:flex-row items-center justify-between gap-4" style={{ background: C.oakDeep, borderTop: "1px solid rgba(185,139,62,0.2)" }}>
        <span style={{ ...display, fontSize: 15, color: C.brassBright, letterSpacing: "0.08em" }}>{siteContent.brand.name}</span>
        <span style={{ ...mono, fontSize: 11, color: C.parchmentDim, opacity: 0.6 }}>{siteContent.brand.footerNote}</span>
      </footer>

      {/* CART DRAWER */}
      {cartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end" style={{ background: "rgba(0,0,0,0.55)" }} onClick={() => setCartOpen(false)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full sm:w-[400px] h-full flex flex-col p-6 overflow-y-auto" style={{ background: C.oakDeep, borderLeft: `1px solid ${C.brass}` }}>
            <div className="flex items-center justify-between mb-6">
              <span style={{ ...display, fontSize: 18, color: C.parchment }}>Your Order</span>
              <button onClick={() => setCartOpen(false)} className="focus-ring" style={{ background: "none", border: "none", color: C.parchmentDim, cursor: "pointer" }}>
                <X size={20} />
              </button>
            </div>

            {checkoutStep === "success" ? (
              <div className="flex flex-col items-center text-center mt-10">
                <Check size={30} color={C.brassBright} />
                <h3 style={{ ...display, fontSize: 20, color: C.parchment, marginTop: 14 }}>Order placed</h3>
                <p style={{ color: C.parchmentDim, marginTop: 8, fontSize: 14 }}>We've sent a confirmation to {checkoutForm.email || "your email"}.</p>
                <p style={{ ...mono, fontSize: 12, color: C.brassBright, marginTop: 10 }}>REFERENCE {orderRef}</p>
                <button onClick={resetCart} className="focus-ring mt-8" style={{ ...mono, fontSize: 12, background: "transparent", border: `1px solid ${C.brass}`, color: C.brassBright, padding: "10px 18px", borderRadius: 4, cursor: "pointer" }}>
                  CONTINUE BROWSING
                </button>
              </div>
            ) : cart.length === 0 ? (
              <p style={{ color: C.parchmentDim, opacity: 0.7, marginTop: 20 }}>Your cart is empty. Add a ticket or something from the store.</p>
            ) : checkoutStep === "cart" ? (
              <>
                <div className="flex flex-col gap-4 flex-grow">
                  {cart.map((i) => {
                    const p = findProduct(i.id);
                    if (!p) return null;
                    return (
                      <div key={i.id} className="flex items-start justify-between gap-3 pb-4" style={{ borderBottom: "1px solid rgba(185,139,62,0.15)" }}>
                        <div>
                          <div style={{ ...body, fontSize: 14, color: C.parchment }}>{p.name}</div>
                          <div style={{ ...mono, fontSize: 12, color: C.brassBright, marginTop: 3 }}>{fmt(p.price)}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={() => changeQty(i.id, -1)} className="focus-ring" style={qtyBtnStyle}><Minus size={12} /></button>
                          <span style={{ ...mono, fontSize: 13, color: C.parchment, width: 16, textAlign: "center" }}>{i.qty}</span>
                          <button onClick={() => changeQty(i.id, 1)} className="focus-ring" style={qtyBtnStyle}><Plus size={12} /></button>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="flex items-center justify-between mt-6 mb-4">
                  <span style={{ ...mono, fontSize: 13, color: C.parchmentDim }}>TOTAL</span>
                  <span style={{ ...mono, fontSize: 16, color: C.brassBright }}>{fmt(cartTotal)}</span>
                </div>
                <button onClick={() => setCheckoutStep("form")} className="focus-ring" style={{ ...mono, fontSize: 13, background: C.ember, color: C.cream, padding: "14px", border: "none", borderRadius: 4, cursor: "pointer" }}>
                  CHECKOUT
                </button>
              </>
            ) : (
              <form onSubmit={placeOrder} className="flex flex-col gap-4 mt-2">
                <label className="flex flex-col gap-1">
                  <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>NAME</span>
                  <input required value={checkoutForm.name} onChange={(e) => setCheckoutForm({ ...checkoutForm, name: e.target.value })} className="focus-ring" style={inputStyle} />
                </label>
                <label className="flex flex-col gap-1">
                  <span style={{ ...mono, fontSize: 11, color: C.parchmentDim }}>EMAIL</span>
                  <input required type="email" value={checkoutForm.email} onChange={(e) => setCheckoutForm({ ...checkoutForm, email: e.target.value })} className="focus-ring" style={inputStyle} />
                </label>
                <div className="flex items-center justify-between mt-2 mb-1">
                  <span style={{ ...mono, fontSize: 13, color: C.parchmentDim }}>TOTAL</span>
                  <span style={{ ...mono, fontSize: 16, color: C.brassBright }}>{fmt(cartTotal)}</span>
                </div>
                <button type="submit" className="focus-ring" style={{ ...mono, fontSize: 13, background: C.ember, color: C.cream, padding: "14px", border: "none", borderRadius: 4, cursor: "pointer" }}>
                  PLACE ORDER
                </button>
                <button type="button" onClick={() => setCheckoutStep("cart")} className="focus-ring" style={{ ...mono, fontSize: 12, background: "transparent", border: "none", color: C.parchmentDim, cursor: "pointer" }}>
                  ← Back to cart
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

const inputStyle = {
  background: "rgba(239,227,194,0.05)",
  border: "1px solid rgba(185,139,62,0.3)",
  borderRadius: 4,
  padding: "10px 12px",
  color: "#F3EAD3",
  fontFamily: "'Fraunces', serif",
  fontSize: 14,
};

const qtyBtnStyle = {
  width: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center",
  border: "1px solid rgba(185,139,62,0.4)", borderRadius: 4, background: "transparent", color: "#D8AC5C", cursor: "pointer",
};
