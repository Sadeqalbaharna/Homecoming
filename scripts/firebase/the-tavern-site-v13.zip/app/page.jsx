import TavernSite from "@/components/TavernSite";

// This page just renders the client component — all live data (menu,
// events, site content) is fetched client-side after hydration, so
// there's nothing to fetch here at request time.
export default function Home() {
  return <TavernSite />;
}
