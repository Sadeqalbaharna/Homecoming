import "./globals.css";

export const metadata = {
  title: "The Tavern — Adliya, Bahrain",
  description:
    "The Main Hall downstairs, Alchemy House upstairs. Food, drink, D&D nights, MTG nights, and guided potion-making in Adliya, Block 338, Bahrain.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
