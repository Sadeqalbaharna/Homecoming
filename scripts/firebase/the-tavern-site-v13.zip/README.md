# The Tavern — Website

Next.js site for The Tavern (Adliya, Block 338, Bahrain). Wired to the same Firebase backend (`kingdom-ac44f`) as the staff ops console (`tavern_console.html`) and the Flutter loyalty app, so menu, event, and site-content edits made by staff show up here automatically.

## Getting started

```
npm install
npm run dev
```

Open http://localhost:3000. For a production build:

```
npm run build
npm run start
```

Requires Node 18.18+ (Next.js 14 requirement).

## Project structure

```
app/
  layout.jsx      — root layout, page metadata
  page.jsx         — renders the TavernSite component
  globals.css      — Tailwind directives
components/
  TavernSite.jsx   — the full site (nav, hero, floors, menu, events, potions, store, booking, footer, cart drawer)
lib/
  firebase.js      — Firebase app/Firestore/RTDB/Auth init, shared with the console's project
tailwind.config.js — scans app/ and components/ for class names
next.config.mjs
netlify.toml        — build command + @netlify/plugin-nextjs
.env.local.example — optional overrides for the Firebase config
```

`TavernSite.jsx` is a client component (`"use client"`) since it uses hooks, browser APIs, and live Firebase reads/writes.

## What's live vs. still mock

**Live, reading from the same Firebase project as the console:**

- **Site content** — hero copy, floor descriptions, potion details, contact info, social handles/links, store items, section order, per-section hide/show, a 5-color theme, and brand/button text are all read from Realtime Database `/site_content`, edited from the console's Site Content tab. The site falls back to sensible defaults if that node is missing or a field wasn't filled in yet.
- **Menu** — reads Realtime Database `/menu` directly (the same node the console's Menu Manager edits). Split into switchable category tabs (whatever categories exist in the live data — e.g. Hearty Meals, Sandwiches, Everyday Drinks), rather than a Main Hall / Alchemy House split, because the real menu doesn't carry a floor tag today. A per-item "servable at" field could be added later if the two floors need different menus — flagged as a possible follow-up, not built yet.
- **Events** — reads Firestore `huntboard/events` (the doc the console's Quest Board tab writes to). If that doc is empty, the calendar just shows no events for every date — it does not fall back to invented placeholder events, unlike the console's own UI which shows local mock data when the doc is empty.
- **Table booking** — "Confirm Reservation" writes a real document into Firestore `/bookings`, using the same field shape as existing console bookings (`guestName`, `date`, `time`, `partySize`, `note`, `status: "pending"`, `reminderSent`, `uid`) plus `phone`, `floor`, `source: "website"`, and `displayRef` as additive fields (the console doesn't render these yet, but they don't break anything since Firestore documents are schemaless). New bookings show up in the console's Bookings tab for staff to confirm/seat like any other reservation. Sign-in is anonymous Firebase Auth (`signInAnonymously`) — there's no visible login step for the guest.
- **Social links** — clickable whenever a URL is set in the console's Social panel; otherwise shown as plain text.
- **Images** — hero background and per-store-item images render from an image URL field once one is set in the console; both are blank/icon-based by default.

**Still mock — no backend source for these yet:**

- **Store checkout** — "Place Order" generates a random reference client-side. No payment processor, no order storage, no email confirmation. The console's Menu Manager doesn't currently have a merch/tickets category, so there's nowhere for this to read from yet.
- **Contact info defaults** — until edited in the console, phone is a placeholder (`+973 XXXX XXXX`) and address is generic, not geocoded or map-embedded.
- **Menu item photos** — the real menu data has an `imageUrl` field per item, currently empty for the live data. The menu list itself doesn't render photos yet (the Store section does); wiring is a small addition once photos exist.

## Important: security rules

While testing which collections were readable to scope this project, `/bookings`, `/menu`, `/site_content`, and `/active_guests` were all found to have open (public) read/write rules on the shared Firebase project. This is intentional for now — the owner is working solo, not live publicly yet — but before opening the site to real customers, these should be locked down with proper Firestore/RTDB security rules (for example: public read, but writes gated behind authentication or a Cloud Function).
